import React,{useEffect,useState} from 'react';
import {SafeAreaView,Text,View,FlatList,Pressable,StyleSheet,Alert} from 'react-native';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import {initializeApp} from 'firebase/app';
import {getFirestore,collection,onSnapshot,doc,updateDoc,setDoc,serverTimestamp} from 'firebase/firestore';
import {firebaseConfig} from './firebaseConfig';

Notifications.setNotificationHandler({handleNotification:async()=>({shouldShowBanner:true,shouldShowList:true,shouldPlaySound:true,shouldSetBadge:true})});
const fb=initializeApp(firebaseConfig); const db=getFirestore(fb);

async function registerPush(){
  if(!Device.isDevice) return;
  const p=await Notifications.getPermissionsAsync();
  let status=p.status;
  if(status!=='granted') status=(await Notifications.requestPermissionsAsync()).status;
  if(status!=='granted') return;
  const token=(await Notifications.getDevicePushTokenAsync()).data;
  await setDoc(doc(db,'drivers','main'),{fcmToken:token,updatedAt:serverTimestamp()},{merge:true});
}

export default function App(){
 const [rides,setRides]=useState([]);
 useEffect(()=>{registerPush().catch(()=>{});return onSnapshot(collection(db,'rides'),s=>setRides(s.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0)));},[]);
 const decide=async(r,status)=>{try{await updateDoc(doc(db,'rides',r.id),{status,answeredAt:serverTimestamp()});}catch(e){Alert.alert('Erro',String(e.message||e));}};
 return <SafeAreaView style={s.root}><Text style={s.title}>Solicitações de corrida</Text><FlatList data={rides} keyExtractor={x=>x.id} ListEmptyComponent={<Text style={s.empty}>Nenhuma solicitação.</Text>} renderItem={({item:r})=><View style={s.card}><Text style={s.name}>{r.customerName||'Cliente'}</Text><Text>Origem: {r.origin||'-'}</Text><Text>Destino: {r.destination||'-'}</Text><Text>Data/hora: {r.date||'-'} {r.time||''}</Text><Text style={s.status}>Status: {r.status||'pending'}</Text>{(!r.status||r.status==='pending')&&<View style={s.row}><Pressable style={s.btn} onPress={()=>decide(r,'accepted')}><Text style={s.bt}>ACEITAR</Text></Pressable><Pressable style={s.btn} onPress={()=>decide(r,'rejected')}><Text style={s.bt}>RECUSAR</Text></Pressable></View>}</View>}/></SafeAreaView>;
}
const s=StyleSheet.create({root:{flex:1,padding:18,backgroundColor:'#fff'},title:{fontSize:25,fontWeight:'700',marginBottom:12},empty:{marginTop:30,textAlign:'center'},card:{padding:16,borderWidth:1,borderColor:'#ddd',borderRadius:14,marginBottom:12,gap:4},name:{fontSize:18,fontWeight:'700'},status:{fontWeight:'700',marginTop:5},row:{flexDirection:'row',gap:10,marginTop:12},btn:{backgroundColor:'#222',padding:12,borderRadius:9,flex:1,alignItems:'center'},bt:{color:'#fff',fontWeight:'700'}});
