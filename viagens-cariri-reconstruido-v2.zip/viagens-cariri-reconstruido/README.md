# Viagens Cariri – reconstrução v2

Este pacote NÃO é o código-fonte original recuperado do APK. É uma reconstrução limpa do fluxo pedido: página pública de solicitação, lista no app do motorista, aceitar/recusar e estrutura de push FCM.

## 1. Gerar APK com Expo EAS
1. Instale Node.js no computador.
2. Na pasta do projeto: `npm install`
3. `npm install -g eas-cli`
4. `eas login`
5. `eas build:configure`
6. `eas build -p android --profile preview`
7. Ao terminar, o EAS fornece o APK para instalação.

## 2. Página do cliente
A pasta `web/` contém a página de agendamento. Publique-a em Firebase Hosting, GitHub Pages, Cloudflare Pages ou outro host estático. O link gerado/compartilhado deve apontar para essa página, e não para a antiga rota emergent.host.

## 3. Firestore
Crie/ative Firestore no projeto `viagens-cariri`. `firestore.rules` incluído é SOMENTE para teste inicial e é permissivo. Antes de produção, implemente autenticação e regras restritas.

## 4. Push
O servidor em `server/` observa novas corridas e envia FCM para o token salvo pelo app. Hospede-o em um serviço Node. Configure a variável secreta `FIREBASE_SERVICE_ACCOUNT_JSON` com a NOVA service account. NUNCA coloque service-account.json no APK, no GitHub ou no ZIP.

## Segurança
A chave administrativa antiga enviada na conversa não está incluída neste ZIP. O arquivo google-services.json é configuração cliente Android e está incluído.
