export const firebaseConfig = {
  apiKey: "AIzaSyBonN3Kd2UkPTddtQsEcCO2z6QTAJR1NNg",
  authDomain: "viagens-cariri.firebaseapp.com",
  projectId: "viagens-cariri",
  storageBucket: "viagens-cariri.firebasestorage.app",
  messagingSenderId: "587407414127",
  appId: "1:587407414127:android:01313caaf7bc529f220e9a"
};
