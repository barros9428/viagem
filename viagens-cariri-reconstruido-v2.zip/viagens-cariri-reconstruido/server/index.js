import express from 'express';import admin from 'firebase-admin';
const cred=process.env.FIREBASE_SERVICE_ACCOUNT_JSON;if(!cred)throw new Error('Defina FIREBASE_SERVICE_ACCOUNT_JSON com a NOVA chave de serviço.');
admin.initializeApp({credential:admin.credential.cert(JSON.parse(cred))});const db=admin.firestore();const app=express();app.use(express.json());
let seen=new Set();db.collection('rides').onSnapshot(async snap=>{for(const ch of snap.docChanges()){if(ch.type!=='added'||seen.has(ch.doc.id))continue;seen.add(ch.doc.id);const r=ch.doc.data();const d=await db.doc('drivers/main').get();const token=d.data()?.fcmToken;if(token)try{await admin.messaging().send({token,notification:{title:'Nova solicitação de corrida',body:`${r.customerName||'Cliente'}: ${r.origin||''} → ${r.destination||''}`},data:{rideId:ch.doc.id}});}catch(e){console.error(e.message);}}});
app.get('/health',(q,s)=>s.json({ok:true}));app.listen(process.env.PORT||3000);
